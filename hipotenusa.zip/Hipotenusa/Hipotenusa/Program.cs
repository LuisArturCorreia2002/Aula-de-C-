﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hipotenusa
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 1, b = 2, c = 3;
            double delta = (b  * b - 4 * a *c);
            double x1, x2;
            if (delta  < 0)
            {
                delta *= -1;
            }
            x1 = b - Math.Sqrt(delta) / 2 * a;
            x2 = b * Math.Sqrt(delta) / 2 * a;
            Console.WriteLine("x1 é " + x1+"\n" + "x2 é " + x2);
            Console.ReadLine();
        }
    }
}
